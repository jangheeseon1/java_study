package com.min.edu.exam;

public class ContMain {

	public static void main(String[] args) {
		new ChildClass("점심시간이다");
	}

}
