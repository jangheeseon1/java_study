package com.min.edu.exam;

//TODO 201 부모 클래스 작성
public class ParentsClass {

	/*
	 * ### 부모의 생성자를 오버로딩을 default 생성자를 사라짐
	 *     따라서 생성자를 오버로딩 했는데 
	 *     default 생성자도 필요로 한다면 
	 *     *반드시* 명시적으로 선언해줘야 한다
	 */
	
	// 생성자 오버로딩
	public ParentsClass(String msg) {// 점심시간이다
		System.out.println("부모의 생성자 호출 : "+ msg);
	}
	
//	public ParentsClass() {
//		// TODO Auto-generated constructor stub
//	}
	
}






