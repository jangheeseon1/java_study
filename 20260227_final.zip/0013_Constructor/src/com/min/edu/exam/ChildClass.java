package com.min.edu.exam;

// extends 했는 오류 발생하지
// 클래스에 오류 표시가 뜨면 생성자에 관련 코드 오류
// 체이닝
public class ChildClass extends ParentsClass {

	public ChildClass(String msg) { // 점심시간이다
		super(msg);// 점심시간이다
		System.out.println("난 자식의 생성자 호출");
	}
	
	

}
