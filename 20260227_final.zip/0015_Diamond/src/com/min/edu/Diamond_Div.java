package com.min.edu;

public class Diamond_Div {

	
	/**
	 * TODO 103 묶음으로 increase 와 decrease를 실행하는 
	 * 위임(deligate)를 메소드를 만들자
	 */
	public void printProcess(int n) {
		this.printIncrease(n);
		this.printDecrease(n);
	}
	
	/**
	 * TODO 101 피라미드 모양을 출력하는 메소드
	 * 
	 * @param n 피라미드 층수 <br>
	 *          층수 3 그림□ 그림■ 연산 연산(홀수 +1 -1) □□■□□ 0 2 1 3-i-1 2*i+1 □■■■□ 1 1 3
	 *          ■■■■■ 2 0 5
	 */

	private void printIncrease(int n) { // test 값:3
		for (int i = 0; i < n; i++) { // 0 1 2

			// 그림 ☆
			for (int j = 0; j < n - i - 1; j++) {
				System.out.print("☆");
			}
			// 그림 ★
			for (int j = 0; j < 2 * i + 1; j++) {
				System.out.print("★");
			}
			// 그림 ☆
			for (int j = 0; j < n - i - 1; j++) {
				System.out.print("☆");
			}
			System.out.println();
		}

	} // printIncrease 끝

	
	/**
	 * TODO 102  역피라미드 출력
	 * @param n
	 * 
	 * 			층수 3	그림□		그림	■	연산		연산(홀수 +1 -1)		
		■■■■■	0		0		5		i		2*(n-i-1)+1		2*(3-0-1)+1	5
		□■■■□	1		1		3				2*(3-1-1)+1		3
		□□■□□	2		2		1				2*(3-2-1)+1		1
	 */
	
	private void printDecrease(int n) {
		for (int i = 1; i < n; i++) { // 반복은 해주는 for문
			
			for (int j = 0; j < i; j++) {
				System.out.print("☆");
			}
			for (int j = 0; j < 2*(n-i-1)+1; j++) {
				System.out.print("★");
			}
			for (int j = 0; j < i; j++) {
				System.out.print("☆");
			}
			System.out.println();
		}
	} // decrease 끝
	
	
	
	
	
	
	
	
	
	
	
	
	
}
