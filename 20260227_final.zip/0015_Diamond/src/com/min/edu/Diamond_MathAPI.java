package com.min.edu;

//TODO 401 Math.abs()를 통해서 절대값 연산을 통한 변화값의 처리
public class Diamond_MathAPI {

	public void dia_math_api(int n) {
		
		for (int i = 0; i < n; i++) { //층수 , 반복을 위한 for문 // 0 1 2 3 4
			System.out.print(Math.abs(i-n/2)); // i층번호 , n/2 이전코드에서 mid로 만들 변수
			
			for (int j = 0; j < Math.abs(i-n/2); j++) { // Math.abs(0-2=-2)=>2, 1-2=-1 ,2-2=0 , 3-2=1 ,4-2=2
				System.out.print("☆");
			}
			
			for (int j = 0; j < n - 2*(Math.abs(i-n/2)); j++) { // 5 - 2*2 = 1
				System.out.print("★");
			}
			
			System.out.println();
			
		}
	}
	
}
