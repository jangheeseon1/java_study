package com.min.edu;

// TODO for문연습 :  for문의 local 변수를 값을로 사용하는 방법
//                 for문의 반복을 제어하는 방법
public class Triangle {

	
	/**
	 * 첫번째 삼각형 그림
	 * @param n 생성되는 층수
	 */
	public void one(int n) { //
		for (int i = 0; i < n; i++) { // 0부터 n까지 반복하겠다 
			for (int j = 0; j < i+1; j++) { // i를 변화는 값으로 사용
				System.out.print("■");
			}
			System.out.println(); // j for문 완료후 다음 줄로 내림
		}
	} // one 끝

	
	/**
	 * 두번째 그림 출력
	 * @param n 층수
	 */
	public void two(int n) { // n은 층수
		for (int i = 0; i < n; i++) { // 4 , 0 1 2 3
			for (int j = 0; j < n -i; j++) {
				System.out.print("■");
			} // 그림 for문
			System.out.println(); // j for문 완료후 다음 줄로 내림
		}
	} //two 끝
	
	/**
	 * 세번째 그림 출력 <br>
	 * 두번째 그림과 첫번째 그림 for문 합쳐서 작성 함 
	 * @param n 입력되는 층수
	 */
	public void three(int n) { // n은 테스트 값을 5
		for (int i = 0; i < n; i++) { // 0 1 2 3 4
			
			// □ 그려주는 for
			for (int j = 0; j < n-i-1; j++) {
				System.out.print("□");
			}
			// ■ 그려주는 for
			for (int j = 0; j < i+1; j++) {
				System.out.print("■");
			}
			System.out.println();
		}
	}// three 끝
	
	
	/**
	 * 네번째 그림 출력
	 * @param n 입력 받은 층수
	 */
	public void four(int n) { // n은 층수: 5 ,  0 1 2 3 4
		for (int i = 0; i < n; i++) { // 층수의 for문
			
			// 그림 □
			for (int j = 0; j < i; j++) { // 0
				System.out.print("□");
			}
			// 그림 ■
			for (int j = 0; j < n-i; j++) { //5
				System.out.print("■");
			}
			System.out.println();
		}
	}
	
	
} // class 끝









