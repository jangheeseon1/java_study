package com.min.edu;

// TODO 004 char 연산
public class Char_Operation {

	/*
	 * char는 3개의 리터를 값을 가지고 있다
	 *  ㄴ uncode 표를 따라간다 => 'A' => 숫자 65 이다, 'B' => 숫자 66 이다
	 *  ㄴ 16진수 : '\u0041';
	 */
	public void charLiteral() {
		char c1 = 'A'; // char의 리터럴은 ''
		char c2 = 65;  // char의 리터럴은 숫자 표의 위치
		
		System.out.println(c1);
		System.out.println(c2);
		
		// char의 정수 연산이 진행될 경우 자동으로 리터럴의 값은 정수 변경된다
		// java에서 연산의 기본 정수 연산(int)
		System.out.println(c1+1); // 연산은 정수연산이니깐
		
		int i1 = c1+1; // 정수연산 'A' -> 65 + 1 => 66 나온다
		char result = (char)i1;
		
		System.out.println(result);
	}
	
	
	
	
	
	
}











