package com.min.edu;

// TODO 005 논리 연산자
public class Logical_Operation {

	
	public void logical() {
		// & | !(부정연산자)
		// !(true) => false
		
		// 왜 개발을 할때 |, & 하나를 사용하지 않고 ||, && 를 많이 사용했는지
		// ||, && short circuit
		
		// 한개 로 되어 있는 논리연산은 앞뒤의 상황에 상관없이 모두 실행 된다. 코드가 너무 많이 실행 됨
		boolean isc1 = trueValue() & falseValue(); // true & false => false
		boolean isc2 = falseValue() & trueValue(); // false & true => false
		/*
		 * 아 놔.... true 가 앞에 나오지 않으면 어차피 false 잖아 왜 뒤에를 연산해 
		 *          그냥 앞에 결과가 false 뒤에 하지마
		 */
		System.out.println("-".repeat(30));
		boolean isc3 = trueValue() && falseValue();
		boolean isc4 = falseValue() && trueValue();
		
	} // logical 끝
	
	// 내 클래스에서만 사용하는 반환타입이 있는 메소드를 만듬
	private boolean trueValue() {
		System.out.println("난 trueValue를 실행 시킴");
		return true;
	}
	
	private boolean falseValue() {
		System.out.println("난 falseValue를 실행 시킴");
		return false;
	}
}











