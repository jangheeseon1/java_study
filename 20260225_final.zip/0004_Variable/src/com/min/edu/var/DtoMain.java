package com.min.edu.var;

public class DtoMain {

	public static void main(String[] args) {
		
		InfoUserDto dto01 = new InfoUserDto();
		dto01.name = "도우너";
		dto01.hobby = "바이올린";
		dto01.etc = "기타"; // static은 static 호출 방식으로 호출 해주세요 권고사항
		
		dto01.make(700); // argument 필요 한다. 변수와 값
		
	}

}
