package com.min.edu;

import java.util.Scanner; // import는 물리적으로 구분되있는 클래스의 위치를 명시적으로 나타내는 것
/*
 * 내가 집에 삼성TV(s-001: 인터넷)
 * 친구집에 삼성TV(s-001: 인터넷 x)
 *
 * 내.거실.TV => 인터넷이 되는 TV 사용
 * 친구.거실.TV => 인터넷이 안되는 TV 사용 
 * 이와 같인 클래스명이 같지만 다른곳에 위치해서 다른 기능을 갖는 것을 구분하기 위해서 import에 명식적으로 내 class에서 사용하는 
 * 클래스를 명시적으로 작성하는 것
 * 
 */
public class IfMain {

	public static void main(String[] args) {
		
		// Scanner 클래스는 java에서 IO(input, output)에서 쉽게 형변환을 통해서 값을 만들어 낼 수 있는 클래스
		Scanner scan = new Scanner(System.in); // System 메모리, in 읽어옴 => 키보드에 입력한 값을 읽어오는 기능
		System.out.println("사용되는 정수값을 입력해 주세요 (❁´◡`❁)");
		int input = scan.nextInt();
		System.out.println("입력받은 정수 값 : " + input);
		
		// 3 4 5 6 7 8 9 10 => 입력하는 숫자 , 3그룹으로 구분하는 IF문을 만들어 주세요
//		if(input > 0) {
//			System.out.println("입력받은 값은 양수이다");
//		}else {
//			System.out.println("입력받은 값은 음수이다");
//		}
		
		/*  / 몫 , % 나머지
		 *  홀수 %사용하면 되는구나 => i%2 == 1  
		 *  / 4의 배수 /사용하면 되는 구나 => i%4 == 0,  4/4 =1, 8/4 = 2 
		 *  / 4의 배수로 나워서 2가 남는것 => i%4 == 2,  6%4 =2  10%4=2 
		 */
		
		if(input % 2 == 1) {
			System.out.println("홀수 입니다");
		}else if(input %4 == 0) {
			System.out.println("4의 배수입니다");
		}else if(input % 4 == 2) {
			System.out.println("4배수+2 입니다");
		}
		
		
		if(input % 2 == 1) {
			System.out.println("홀수 입니다");
		}else if(input %4 == 0) {
			System.out.println("4의 배수입니다");
		}else{
			System.out.println("4배수+2 입니다");
		}
		
		
		
		
		// 여러개의 조건절
		if(input == 1) {
			System.out.println("1이 입력됨");
		}else if(input == 2) {
			System.out.println("2가 입력됨");
		}else if(input == 3) {
			System.out.println("3이 입력됨");
		}else {
			System.out.println("4이상의 값을 입력함");
		}
		
		
	}

}









