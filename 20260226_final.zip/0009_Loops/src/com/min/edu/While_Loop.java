package com.min.edu;

//TODO 002 while , do ~ while
public class While_Loop {

	public static void main(String[] args) {
		// while 루프는 지정된 조건이 true인 경우에만 코드블록({}) 을 통해서 실행되고 조건이 true 유지되는 동한 루프를 계속한다
		int x = 0;
		while (x< 5) { // 조건 : 첫번째 조건 판단
			System.out.println(x++); //  01234 // 선처리 후 증가
		}
		
		System.out.println("-".repeat(20));
		// do ~ while : 작동 방식은 같으나 먼저 한번 연산을 실행 후 동작
		int y= 0;
		do {
			System.out.println(y++);
		} while (y<5);
		
		
		int z = 0;
		while (z< 5) { // 
			System.out.println(++z); //  
		}
		/* z=0      조건(0<5)     출력(1)
		 * z=1      조건(1<5)     출력(2)
		 * z=2      조건(2<5)     출력(3)
		 * z=3      조건(3<5)     출력(4)
		 * z=4      조건(4<5)     출력(5)
		 * z=5      조건(5<5)     로프탈출  
		 */
	}
}
