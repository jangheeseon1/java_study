package com.min.edu;

public class Break_Continue {

	// TODO 001 
	// Loop에서 사용할 수 있는 두 가지 특수 키워드
	//  상황 : 강제로 loop 종료, 특정한 조건일 때 연산은 건너 뛰고 처음으로 실행하고 싶을때
	public static void main(String[] args) {
		
		int n= 0;
		while (true) { //  무한루프로 계속해서 while문의 연산을 실행 , 전:(n<5) 
			System.out.println(n++); // 선처리 후증가 : 0 출력이 되고 +1이 나감
			if(n == 5) { // 0 :f , 1:f, 2:f, 3:f , 4:f , 5:t->break 실행-> loop 밖으로 탈출
				break;
			}
		}
		
		System.out.println("^_^".repeat(10));
		
		for (int i = 0; i < 10; i++) { // 0 
			if(i == 5) { // 0:f, 1:f, 2:f, 3:f, 4:f ,5:t->break실행 종료
				break;
			}
			if(i == 3) { // 0:f, 1:f, 2:f, 3:t->continue동작(처음으로), 4:f
				continue;
			}
			
			System.out.println(i); //0,1,2,4
		}
		
	} // main
	
} //class




