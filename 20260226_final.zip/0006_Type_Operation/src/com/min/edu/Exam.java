package com.min.edu;


public class Exam {

	// char숫자 -> int숫자
	public void charnumTointNum() {
		char c = '9'; // 숫자(int) 9로 출력 하는 방법
		//정의한님 답글 : (int)c ????? => 코드는 문제가 없지만 9는 나오지 않는다 => 코드표 나오기때문에 code표의 숫자
		int result01 = (int)c; 
		System.out.println("나와라 (*/ω＼*) :" + result01);
		char z = '0';
		int result02 = c - z;
		System.out.println("나왔다 :-D " + result02);
		
		// 백성민님 사연 : toNumber() ???? 
		// core언어인데 사람들이 많아 사용하는 좀 만들어 놨겠지??? 당연하죠
		// static 메소드로 미리 만들어 놓음
		// char에 기능을 가진 집합체 Character 클래스에 있다
		
		// static으로 되어 있는 멤버를 클래스명. 으로 호출 한다
		// getNumericValue는 반드시 char타입을 Argument로 필요 한다
		// getNumericValue의 반환 타입은 int이다. 어떻게 알 수 있을까? 메소드에 마우스 올려보세요
		//
//		int java.lang.Character.getNumericValue(
//				char ch
//				)
		// 그래서 int의 그릇(변수)를 선언하고 담아 주고 필요시 다음 연산으로 진행하면 된다

		int result03 = Character.getNumericValue(c);
		System.out.println(result03);
	} // charnumTointNum 끝
	
	
	public void charnumTointNum2() {
		// '9'-'0' => 연산은 정수연산이 우선이고, 참여하는 타입에 따라서 출력이 타입이 정해 진다
		int n = '9';
		int m = '0';
		
		int result = n-m;
		System.out.println("'9'-'0'의 결과 : "+ result); // concatnation 연쇄 : 문자열과 만나면 모든 것들은 보이는 그래도 문자열이 된다
		//명시적 형변환
		System.out.println((char)result);
	}// charnumTointNum2 끝
	
	public void charToIntToChar() {
		//(char)('A'+2) = > 'C'
		char A = 'A';
		char C = 'C';
		System.out.println((int)A); // Unicode 표에서 'A'는 65를 가진다
		System.out.println((int)C); // 67
		
		int n = 65+2;
		char nc = (char)n;
		System.out.println(nc);
		
		//for문은 Loof 연산, 반복한다
		//local variable, 증감연산자, 논리연산
		for (int i = 0; i < 100; i++) { // 0 1 2 3 ... 99 변수 i가 변하면 실행이 된다
			System.out.println(i + "값  :" + (char)i);
		}
		
		//Unicode는 전체를 보여 주지 않습니다
		// 0 , 1 
	}
	
	/*
	 *  '9' => 57
	 *  '0' => 48
	 *  '9'-'0' => 연산은 숫자연산 => 57-48 => 9 int 값을 결과를 반환됨 = int n = '9'-'0'; => int n = 9; 
	 */
	
	
	
}





